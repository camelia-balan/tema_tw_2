function addTokens(input, tokens){

      if(!verifica(input)) {
       throw new Error("Invalid input");
    }

     if(input.length < 6) {
       throw new Error("Input should have at least 6 characters");
     }

      for (var i = 0; i < tokens.length; i++) {
        if(!verifica(tokens[i].tokenName)){
            throw new Error('Invalid array format');
        }
    }
    
    if(!input.includes('...')) {
      return input;
    }

    if(input.includes('...')) {
      for(var i = 0; i<tokens.length; i++) {
        var newInput = input.replace('...', "${"+tokens[i].tokenName+"}");
      }
      return newInput;
    }
}

const app = {
   addTokens: addTokens
}

    
function verifica(text) {
  return (typeof text==="string" || text instanceof String);
}

module.exports = app;